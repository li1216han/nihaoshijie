from flask import Flask, request, redirect, render_template, url_for
import os
import uuid
from datetime import datetime

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'

# 确保目录存在
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['photo']
    if file:
        filename = datetime.now().strftime('%Y%m%d_') + uuid.uuid4().hex + os.path.splitext(file.filename)[-1]
        path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(path)
        return redirect(url_for('gallery'))  # 上传成功后跳转
    return '上传失败'

@app.route('/gallery')
def gallery():
    # 读取所有图片路径
    files = os.listdir(app.config['UPLOAD_FOLDER'])
    files = sorted(files, reverse=True)  # 最新的图片在前
    image_urls = [url_for('static', filename='uploads/' + f) for f in files if f.endswith(('.jpg', '.png', '.jpeg'))]
    return render_template('gallery.html', images=image_urls)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

